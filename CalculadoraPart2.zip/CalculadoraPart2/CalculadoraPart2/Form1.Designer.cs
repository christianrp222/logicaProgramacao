﻿namespace CalculadoraPart2
{
    partial class frmCalculadora
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCalculadora));
            this.lblTexto = new System.Windows.Forms.Label();
            this.lblInteiro = new System.Windows.Forms.Label();
            this.lblDecimal = new System.Windows.Forms.Label();
            this.lblBoleano = new System.Windows.Forms.Label();
            this.txtTexto = new System.Windows.Forms.TextBox();
            this.txtBoleano = new System.Windows.Forms.TextBox();
            this.txtDecimal = new System.Windows.Forms.TextBox();
            this.txtInteiro = new System.Windows.Forms.TextBox();
            this.btnAdição = new System.Windows.Forms.Button();
            this.btnSubitração = new System.Windows.Forms.Button();
            this.btnMultiplicação = new System.Windows.Forms.Button();
            this.btnDivisão = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTexto
            // 
            this.lblTexto.AutoSize = true;
            this.lblTexto.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTexto.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTexto.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblTexto.Location = new System.Drawing.Point(70, 22);
            this.lblTexto.Name = "lblTexto";
            this.lblTexto.Size = new System.Drawing.Size(74, 29);
            this.lblTexto.TabIndex = 0;
            this.lblTexto.Text = "Texto";
            // 
            // lblInteiro
            // 
            this.lblInteiro.AutoSize = true;
            this.lblInteiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInteiro.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblInteiro.Location = new System.Drawing.Point(70, 122);
            this.lblInteiro.Name = "lblInteiro";
            this.lblInteiro.Size = new System.Drawing.Size(80, 29);
            this.lblInteiro.TabIndex = 1;
            this.lblInteiro.Text = "Inteiro";
            // 
            // lblDecimal
            // 
            this.lblDecimal.AutoSize = true;
            this.lblDecimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDecimal.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblDecimal.Location = new System.Drawing.Point(70, 217);
            this.lblDecimal.Name = "lblDecimal";
            this.lblDecimal.Size = new System.Drawing.Size(101, 29);
            this.lblDecimal.TabIndex = 2;
            this.lblDecimal.Text = "Decimal";
            // 
            // lblBoleano
            // 
            this.lblBoleano.AutoSize = true;
            this.lblBoleano.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBoleano.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblBoleano.Location = new System.Drawing.Point(70, 304);
            this.lblBoleano.Name = "lblBoleano";
            this.lblBoleano.Size = new System.Drawing.Size(103, 29);
            this.lblBoleano.TabIndex = 3;
            this.lblBoleano.Text = "Boleano";
            // 
            // txtTexto
            // 
            this.txtTexto.Location = new System.Drawing.Point(75, 65);
            this.txtTexto.Multiline = true;
            this.txtTexto.Name = "txtTexto";
            this.txtTexto.Size = new System.Drawing.Size(222, 28);
            this.txtTexto.TabIndex = 4;
            // 
            // txtBoleano
            // 
            this.txtBoleano.Location = new System.Drawing.Point(75, 347);
            this.txtBoleano.Multiline = true;
            this.txtBoleano.Name = "txtBoleano";
            this.txtBoleano.Size = new System.Drawing.Size(222, 28);
            this.txtBoleano.TabIndex = 5;
            // 
            // txtDecimal
            // 
            this.txtDecimal.Location = new System.Drawing.Point(75, 259);
            this.txtDecimal.Multiline = true;
            this.txtDecimal.Name = "txtDecimal";
            this.txtDecimal.Size = new System.Drawing.Size(222, 28);
            this.txtDecimal.TabIndex = 6;
            // 
            // txtInteiro
            // 
            this.txtInteiro.Location = new System.Drawing.Point(75, 166);
            this.txtInteiro.Multiline = true;
            this.txtInteiro.Name = "txtInteiro";
            this.txtInteiro.Size = new System.Drawing.Size(222, 28);
            this.txtInteiro.TabIndex = 7;
            // 
            // btnAdição
            // 
            this.btnAdição.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdição.Location = new System.Drawing.Point(633, 166);
            this.btnAdição.Name = "btnAdição";
            this.btnAdição.Size = new System.Drawing.Size(110, 42);
            this.btnAdição.TabIndex = 10;
            this.btnAdição.Text = "Adição";
            this.btnAdição.UseVisualStyleBackColor = true;
            this.btnAdição.Click += new System.EventHandler(this.btnAdição_Click);
            // 
            // btnSubitração
            // 
            this.btnSubitração.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubitração.Location = new System.Drawing.Point(503, 166);
            this.btnSubitração.Name = "btnSubitração";
            this.btnSubitração.Size = new System.Drawing.Size(110, 42);
            this.btnSubitração.TabIndex = 12;
            this.btnSubitração.Text = "Subitração";
            this.btnSubitração.UseVisualStyleBackColor = true;
            this.btnSubitração.Click += new System.EventHandler(this.btnSubitração_Click);
            // 
            // btnMultiplicação
            // 
            this.btnMultiplicação.BackColor = System.Drawing.SystemColors.Info;
            this.btnMultiplicação.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMultiplicação.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnMultiplicação.Location = new System.Drawing.Point(633, 224);
            this.btnMultiplicação.Name = "btnMultiplicação";
            this.btnMultiplicação.Size = new System.Drawing.Size(110, 42);
            this.btnMultiplicação.TabIndex = 13;
            this.btnMultiplicação.Text = "Multiplicação";
            this.btnMultiplicação.UseVisualStyleBackColor = false;
            this.btnMultiplicação.Click += new System.EventHandler(this.btnMultiplicação_Click);
            // 
            // btnDivisão
            // 
            this.btnDivisão.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDivisão.Location = new System.Drawing.Point(503, 223);
            this.btnDivisão.Name = "btnDivisão";
            this.btnDivisão.Size = new System.Drawing.Size(110, 42);
            this.btnDivisão.TabIndex = 14;
            this.btnDivisão.Text = "Divisão";
            this.btnDivisão.UseVisualStyleBackColor = true;
            this.btnDivisão.Click += new System.EventHandler(this.btnDivisão_Click);
            // 
            // frmCalculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnDivisão);
            this.Controls.Add(this.btnMultiplicação);
            this.Controls.Add(this.btnSubitração);
            this.Controls.Add(this.btnAdição);
            this.Controls.Add(this.txtInteiro);
            this.Controls.Add(this.txtDecimal);
            this.Controls.Add(this.txtBoleano);
            this.Controls.Add(this.txtTexto);
            this.Controls.Add(this.lblBoleano);
            this.Controls.Add(this.lblDecimal);
            this.Controls.Add(this.lblInteiro);
            this.Controls.Add(this.lblTexto);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmCalculadora";
            this.Text = "Calculadora";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTexto;
        private System.Windows.Forms.Label lblInteiro;
        private System.Windows.Forms.Label lblDecimal;
        private System.Windows.Forms.Label lblBoleano;
        private System.Windows.Forms.TextBox txtTexto;
        private System.Windows.Forms.TextBox txtBoleano;
        private System.Windows.Forms.TextBox txtDecimal;
        private System.Windows.Forms.TextBox txtInteiro;
        private System.Windows.Forms.Button btnAdição;
        private System.Windows.Forms.Button btnSubitração;
        private System.Windows.Forms.Button btnMultiplicação;
        private System.Windows.Forms.Button btnDivisão;
    }
}

