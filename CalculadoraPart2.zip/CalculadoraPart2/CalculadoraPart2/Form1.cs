﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraPart2
{
    public partial class frmCalculadora : Form
    {
        public frmCalculadora()
        {
            InitializeComponent();
        }

        private void btnSubitração_Click(object sender, EventArgs e)
        {
            int Inteiro = int.Parse(txtInteiro.Text);
            float Decimal = float.Parse(txtDecimal.Text);
            float resultado;

            //Subitração
            resultado = Inteiro - Decimal;
            MessageBox.Show("Subtração: " + resultado);
        }

        private void btnAdição_Click(object sender, EventArgs e)
        {
            int Inteiro = int.Parse(txtInteiro.Text);
            float Decimal = float.Parse(txtDecimal.Text);
            float resultado;

            //Adição
            resultado = Inteiro + Decimal;
            MessageBox.Show("Adição: " + resultado);
        }

        private void btnMultiplicação_Click(object sender, EventArgs e)
        {
            int Inteiro = int.Parse(txtInteiro.Text);
            float Decimal = float.Parse(txtDecimal.Text);
            float resultado;

            //Multiplicação
            resultado = Inteiro * Decimal;
            MessageBox.Show("Multiplicação: " + resultado);
        }

        private void btnDivisão_Click(object sender, EventArgs e)
        {
            int Inteiro = int.Parse(txtInteiro.Text);
            float Decimal = float.Parse(txtDecimal.Text);
            float resultado;

            //Divisão
            resultado = Inteiro / Decimal;
            MessageBox.Show("Divisão: " + resultado);
        }
    }
}
