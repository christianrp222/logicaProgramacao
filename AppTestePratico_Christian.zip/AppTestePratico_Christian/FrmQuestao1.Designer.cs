﻿namespace AppTestePratico_Christian
{
    partial class Frm
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlTopo = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlFim = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblQtdBroa = new System.Windows.Forms.Label();
            this.lblQtdPaes = new System.Windows.Forms.Label();
            this.txtPaes = new System.Windows.Forms.TextBox();
            this.txtBroa = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblVlrAPagar = new System.Windows.Forms.Label();
            this.lblVlrFinal = new System.Windows.Forms.Label();
            this.pnlTopo.SuspendLayout();
            this.pnlFim.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTopo
            // 
            this.pnlTopo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(186)))), ((int)(((byte)(8)))));
            this.pnlTopo.Controls.Add(this.lblTitulo);
            this.pnlTopo.Location = new System.Drawing.Point(-1, 0);
            this.pnlTopo.Name = "pnlTopo";
            this.pnlTopo.Size = new System.Drawing.Size(803, 93);
            this.pnlTopo.TabIndex = 0;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Location = new System.Drawing.Point(799, 37);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(8, 8);
            this.flowLayoutPanel1.TabIndex = 1;
            // 
            // pnlFim
            // 
            this.pnlFim.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pnlFim.Controls.Add(this.lblVlrFinal);
            this.pnlFim.Controls.Add(this.lblVlrAPagar);
            this.pnlFim.Location = new System.Drawing.Point(-1, 327);
            this.pnlFim.Name = "pnlFim";
            this.pnlFim.Size = new System.Drawing.Size(803, 124);
            this.pnlFim.TabIndex = 2;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Arial Narrow", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(36, 23);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(139, 37);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Questão 1";
            // 
            // lblQtdBroa
            // 
            this.lblQtdBroa.AutoSize = true;
            this.lblQtdBroa.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdBroa.Location = new System.Drawing.Point(36, 207);
            this.lblQtdBroa.Name = "lblQtdBroa";
            this.lblQtdBroa.Size = new System.Drawing.Size(157, 29);
            this.lblQtdBroa.TabIndex = 3;
            this.lblQtdBroa.Text = "Número de Broa";
            // 
            // lblQtdPaes
            // 
            this.lblQtdPaes.AutoSize = true;
            this.lblQtdPaes.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdPaes.Location = new System.Drawing.Point(35, 118);
            this.lblQtdPaes.Name = "lblQtdPaes";
            this.lblQtdPaes.Size = new System.Drawing.Size(158, 29);
            this.lblQtdPaes.TabIndex = 4;
            this.lblQtdPaes.Text = "Numero de pães";
            // 
            // txtPaes
            // 
            this.txtPaes.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPaes.Location = new System.Drawing.Point(42, 158);
            this.txtPaes.Name = "txtPaes";
            this.txtPaes.Size = new System.Drawing.Size(72, 35);
            this.txtPaes.TabIndex = 5;
            // 
            // txtBroa
            // 
            this.txtBroa.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBroa.Location = new System.Drawing.Point(42, 257);
            this.txtBroa.Name = "txtBroa";
            this.txtBroa.Size = new System.Drawing.Size(72, 35);
            this.txtBroa.TabIndex = 6;
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.Yellow;
            this.btnCalcular.Location = new System.Drawing.Point(402, 207);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(120, 85);
            this.btnCalcular.TabIndex = 7;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblVlrAPagar
            // 
            this.lblVlrAPagar.AutoSize = true;
            this.lblVlrAPagar.Font = new System.Drawing.Font("Arial Narrow", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVlrAPagar.Location = new System.Drawing.Point(37, 41);
            this.lblVlrAPagar.Name = "lblVlrAPagar";
            this.lblVlrAPagar.Size = new System.Drawing.Size(198, 37);
            this.lblVlrAPagar.TabIndex = 1;
            this.lblVlrAPagar.Text = "Valor A Pagar :";
            // 
            // lblVlrFinal
            // 
            this.lblVlrFinal.AutoSize = true;
            this.lblVlrFinal.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVlrFinal.Location = new System.Drawing.Point(297, 49);
            this.lblVlrFinal.Name = "lblVlrFinal";
            this.lblVlrFinal.Size = new System.Drawing.Size(50, 29);
            this.lblVlrFinal.TabIndex = 2;
            this.lblVlrFinal.Text = "R$- ";
            // 
            // Frm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(93)))), ((int)(((byte)(4)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtBroa);
            this.Controls.Add(this.txtPaes);
            this.Controls.Add(this.lblQtdPaes);
            this.Controls.Add(this.lblQtdBroa);
            this.Controls.Add(this.pnlFim);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.pnlTopo);
            this.Name = "Frm";
            this.pnlTopo.ResumeLayout(false);
            this.pnlTopo.PerformLayout();
            this.pnlFim.ResumeLayout(false);
            this.pnlFim.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlTopo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel pnlFim;
        private System.Windows.Forms.Label lblQtdBroa;
        private System.Windows.Forms.Label lblQtdPaes;
        private System.Windows.Forms.TextBox txtPaes;
        private System.Windows.Forms.TextBox txtBroa;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblVlrFinal;
        private System.Windows.Forms.Label lblVlrAPagar;
    }
}

