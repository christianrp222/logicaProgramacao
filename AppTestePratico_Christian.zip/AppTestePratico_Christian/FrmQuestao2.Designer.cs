﻿namespace AppTestePratico_Christian
{
    partial class FrmQuestao2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlCima = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblQuestao2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblQtdCamisasM = new System.Windows.Forms.Label();
            this.lblQtdCamisasP = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtQtdCamisasP = new System.Windows.Forms.TextBox();
            this.txtQtdCamisasM = new System.Windows.Forms.TextBox();
            this.lblQtdCasmisasG = new System.Windows.Forms.Label();
            this.txtQtdCamisasG = new System.Windows.Forms.TextBox();
            this.pnlCima.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlCima
            // 
            this.pnlCima.BackColor = System.Drawing.Color.Red;
            this.pnlCima.Controls.Add(this.lblQuestao2);
            this.pnlCima.Location = new System.Drawing.Point(0, 0);
            this.pnlCima.Name = "pnlCima";
            this.pnlCima.Size = new System.Drawing.Size(802, 103);
            this.pnlCima.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 349);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(802, 103);
            this.panel1.TabIndex = 1;
            // 
            // lblQuestao2
            // 
            this.lblQuestao2.AutoSize = true;
            this.lblQuestao2.Font = new System.Drawing.Font("Arial Narrow", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestao2.Location = new System.Drawing.Point(24, 28);
            this.lblQuestao2.Name = "lblQuestao2";
            this.lblQuestao2.Size = new System.Drawing.Size(124, 37);
            this.lblQuestao2.TabIndex = 0;
            this.lblQuestao2.Text = "Qustão 2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(34, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 37);
            this.label1.TabIndex = 2;
            this.label1.Text = "Qustão 2";
            // 
            // lblQtdCamisasM
            // 
            this.lblQtdCamisasM.AutoSize = true;
            this.lblQtdCamisasM.Font = new System.Drawing.Font("Arial Narrow", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdCamisasM.Location = new System.Drawing.Point(24, 183);
            this.lblQtdCamisasM.Name = "lblQtdCamisasM";
            this.lblQtdCamisasM.Size = new System.Drawing.Size(288, 37);
            this.lblQtdCamisasM.TabIndex = 3;
            this.lblQtdCamisasM.Text = "Quantidade caimsas M";
            // 
            // lblQtdCamisasP
            // 
            this.lblQtdCamisasP.AutoSize = true;
            this.lblQtdCamisasP.Font = new System.Drawing.Font("Arial Narrow", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdCamisasP.Location = new System.Drawing.Point(24, 106);
            this.lblQtdCamisasP.Name = "lblQtdCamisasP";
            this.lblQtdCamisasP.Size = new System.Drawing.Size(290, 37);
            this.lblQtdCamisasP.TabIndex = 4;
            this.lblQtdCamisasP.Text = "Quantidade Camisas P";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(257, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(124, 37);
            this.label4.TabIndex = 5;
            this.label4.Text = "Qustão 2";
            // 
            // txtQtdCamisasP
            // 
            this.txtQtdCamisasP.Location = new System.Drawing.Point(39, 160);
            this.txtQtdCamisasP.Name = "txtQtdCamisasP";
            this.txtQtdCamisasP.Size = new System.Drawing.Size(180, 20);
            this.txtQtdCamisasP.TabIndex = 5;
            // 
            // txtQtdCamisasM
            // 
            this.txtQtdCamisasM.Location = new System.Drawing.Point(39, 235);
            this.txtQtdCamisasM.Name = "txtQtdCamisasM";
            this.txtQtdCamisasM.Size = new System.Drawing.Size(180, 20);
            this.txtQtdCamisasM.TabIndex = 6;
            // 
            // lblQtdCasmisasG
            // 
            this.lblQtdCasmisasG.AutoSize = true;
            this.lblQtdCasmisasG.Font = new System.Drawing.Font("Arial Narrow", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdCasmisasG.Location = new System.Drawing.Point(24, 258);
            this.lblQtdCasmisasG.Name = "lblQtdCasmisasG";
            this.lblQtdCasmisasG.Size = new System.Drawing.Size(286, 37);
            this.lblQtdCasmisasG.TabIndex = 7;
            this.lblQtdCasmisasG.Text = "Quantidade caimsas G";
            // 
            // txtQtdCamisasG
            // 
            this.txtQtdCamisasG.Location = new System.Drawing.Point(39, 314);
            this.txtQtdCamisasG.Name = "txtQtdCamisasG";
            this.txtQtdCamisasG.Size = new System.Drawing.Size(180, 20);
            this.txtQtdCamisasG.TabIndex = 8;
            // 
            // FrmQuestao2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtQtdCamisasG);
            this.Controls.Add(this.lblQtdCasmisasG);
            this.Controls.Add(this.txtQtdCamisasM);
            this.Controls.Add(this.txtQtdCamisasP);
            this.Controls.Add(this.lblQtdCamisasP);
            this.Controls.Add(this.lblQtdCamisasM);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlCima);
            this.Name = "FrmQuestao2";
            this.Text = "Form1";
            this.pnlCima.ResumeLayout(false);
            this.pnlCima.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlCima;
        private System.Windows.Forms.Label lblQuestao2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblQtdCamisasM;
        private System.Windows.Forms.Label lblQtdCamisasP;
        private System.Windows.Forms.TextBox txtQtdCamisasP;
        private System.Windows.Forms.TextBox txtQtdCamisasM;
        private System.Windows.Forms.Label lblQtdCasmisasG;
        private System.Windows.Forms.TextBox txtQtdCamisasG;
    }
}