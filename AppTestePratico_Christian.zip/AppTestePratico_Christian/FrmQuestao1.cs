﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_Christian
{
    public partial class Frm : Form
    {
        public Frm()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Pegar os valores na tela
            int Paes = int.Parse(txtPaes.Text);
            int Broas = int.Parse(txtBroa.Text);
            float total;

            //fazer o cálculo
            total = Broas * 1.50f + Paes * 0.12f;

            //Mostrar o resultado na label 
            lblVlrFinal.Text = "R$" + total;
        }
    }
}
