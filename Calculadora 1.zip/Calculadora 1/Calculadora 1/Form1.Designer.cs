﻿namespace Calculadora_1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btn0 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnmc = new System.Windows.Forms.Button();
            this.btnmr = new System.Windows.Forms.Button();
            this.btnms = new System.Windows.Forms.Button();
            this.btnmmenos = new System.Windows.Forms.Button();
            this.btnmmais = new System.Windows.Forms.Button();
            this.btnseta = new System.Windows.Forms.Button();
            this.btnce = new System.Windows.Forms.Button();
            this.btnc = new System.Windows.Forms.Button();
            this.btnraizquadrada = new System.Windows.Forms.Button();
            this.btnmaismenos = new System.Windows.Forms.Button();
            this.btnbarra = new System.Windows.Forms.Button();
            this.btnx2 = new System.Windows.Forms.Button();
            this.btnasterisco = new System.Windows.Forms.Button();
            this.btnmenos = new System.Windows.Forms.Button();
            this.btnigual = new System.Windows.Forms.Button();
            this.btndivisao = new System.Windows.Forms.Button();
            this.btnmais = new System.Windows.Forms.Button();
            this.bntponto = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn0
            // 
            this.btn0.Location = new System.Drawing.Point(250, 349);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(128, 36);
            this.btn0.TabIndex = 0;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = true;
            this.btn0.Click += new System.EventHandler(this.btn0_Click);
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(315, 306);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(63, 37);
            this.btn2.TabIndex = 1;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn5
            // 
            this.btn5.Location = new System.Drawing.Point(315, 264);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(63, 36);
            this.btn5.TabIndex = 2;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn7
            // 
            this.btn7.Location = new System.Drawing.Point(248, 221);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(63, 37);
            this.btn7.TabIndex = 3;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn6
            // 
            this.btn6.Location = new System.Drawing.Point(384, 264);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(58, 36);
            this.btn6.TabIndex = 4;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btn8
            // 
            this.btn8.Location = new System.Drawing.Point(315, 221);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(63, 37);
            this.btn8.TabIndex = 5;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(250, 306);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(61, 37);
            this.btn1.TabIndex = 6;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(384, 306);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(58, 35);
            this.btn3.TabIndex = 7;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn4
            // 
            this.btn4.Location = new System.Drawing.Point(250, 264);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(61, 36);
            this.btn4.TabIndex = 8;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn9
            // 
            this.btn9.Location = new System.Drawing.Point(384, 221);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(58, 37);
            this.btn9.TabIndex = 9;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(250, 68);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(320, 53);
            this.textBox1.TabIndex = 10;
            // 
            // btnmc
            // 
            this.btnmc.Location = new System.Drawing.Point(250, 127);
            this.btnmc.Name = "btnmc";
            this.btnmc.Size = new System.Drawing.Size(61, 36);
            this.btnmc.TabIndex = 11;
            this.btnmc.Text = "MC";
            this.btnmc.UseVisualStyleBackColor = true;
            this.btnmc.Click += new System.EventHandler(this.btnmc_Click);
            // 
            // btnmr
            // 
            this.btnmr.Location = new System.Drawing.Point(315, 127);
            this.btnmr.Name = "btnmr";
            this.btnmr.Size = new System.Drawing.Size(63, 36);
            this.btnmr.TabIndex = 12;
            this.btnmr.Text = "MR";
            this.btnmr.UseVisualStyleBackColor = true;
            this.btnmr.Click += new System.EventHandler(this.btnmr_Click);
            // 
            // btnms
            // 
            this.btnms.Location = new System.Drawing.Point(384, 127);
            this.btnms.Name = "btnms";
            this.btnms.Size = new System.Drawing.Size(58, 36);
            this.btnms.TabIndex = 13;
            this.btnms.Text = "MS";
            this.btnms.UseVisualStyleBackColor = true;
            this.btnms.Click += new System.EventHandler(this.btnms_Click);
            // 
            // btnmmenos
            // 
            this.btnmmenos.Location = new System.Drawing.Point(512, 127);
            this.btnmmenos.Name = "btnmmenos";
            this.btnmmenos.Size = new System.Drawing.Size(58, 36);
            this.btnmmenos.TabIndex = 14;
            this.btnmmenos.Text = "M-";
            this.btnmmenos.UseVisualStyleBackColor = true;
            this.btnmmenos.Click += new System.EventHandler(this.btnmmenos_Click);
            // 
            // btnmmais
            // 
            this.btnmmais.Location = new System.Drawing.Point(448, 127);
            this.btnmmais.Name = "btnmmais";
            this.btnmmais.Size = new System.Drawing.Size(58, 36);
            this.btnmmais.TabIndex = 15;
            this.btnmmais.Text = "M+";
            this.btnmmais.UseVisualStyleBackColor = true;
            this.btnmmais.Click += new System.EventHandler(this.btnmmais_Click);
            // 
            // btnseta
            // 
            this.btnseta.Location = new System.Drawing.Point(250, 169);
            this.btnseta.Name = "btnseta";
            this.btnseta.Size = new System.Drawing.Size(61, 36);
            this.btnseta.TabIndex = 16;
            this.btnseta.Text = " ←";
            this.btnseta.UseVisualStyleBackColor = true;
            this.btnseta.Click += new System.EventHandler(this.btnseta_Click);
            // 
            // btnce
            // 
            this.btnce.Location = new System.Drawing.Point(315, 169);
            this.btnce.Name = "btnce";
            this.btnce.Size = new System.Drawing.Size(63, 36);
            this.btnce.TabIndex = 17;
            this.btnce.Text = "CE";
            this.btnce.UseVisualStyleBackColor = true;
            this.btnce.Click += new System.EventHandler(this.btnce_Click);
            // 
            // btnc
            // 
            this.btnc.Location = new System.Drawing.Point(384, 169);
            this.btnc.Name = "btnc";
            this.btnc.Size = new System.Drawing.Size(58, 36);
            this.btnc.TabIndex = 18;
            this.btnc.Text = "C";
            this.btnc.UseVisualStyleBackColor = true;
            this.btnc.Click += new System.EventHandler(this.btnc_Click);
            // 
            // btnraizquadrada
            // 
            this.btnraizquadrada.Location = new System.Drawing.Point(509, 169);
            this.btnraizquadrada.Name = "btnraizquadrada";
            this.btnraizquadrada.Size = new System.Drawing.Size(61, 36);
            this.btnraizquadrada.TabIndex = 19;
            this.btnraizquadrada.Text = "√";
            this.btnraizquadrada.UseVisualStyleBackColor = true;
            this.btnraizquadrada.Click += new System.EventHandler(this.btnraizquadrada_Click);
            // 
            // btnmaismenos
            // 
            this.btnmaismenos.Location = new System.Drawing.Point(448, 169);
            this.btnmaismenos.Name = "btnmaismenos";
            this.btnmaismenos.Size = new System.Drawing.Size(58, 36);
            this.btnmaismenos.TabIndex = 20;
            this.btnmaismenos.Text = "+ -";
            this.btnmaismenos.UseVisualStyleBackColor = true;
            this.btnmaismenos.Click += new System.EventHandler(this.btnmaismenos_Click);
            // 
            // btnbarra
            // 
            this.btnbarra.Location = new System.Drawing.Point(448, 221);
            this.btnbarra.Name = "btnbarra";
            this.btnbarra.Size = new System.Drawing.Size(58, 37);
            this.btnbarra.TabIndex = 21;
            this.btnbarra.Text = "/";
            this.btnbarra.UseVisualStyleBackColor = true;
            this.btnbarra.Click += new System.EventHandler(this.btnbarra_Click);
            // 
            // btnx2
            // 
            this.btnx2.Location = new System.Drawing.Point(512, 263);
            this.btnx2.Name = "btnx2";
            this.btnx2.Size = new System.Drawing.Size(58, 37);
            this.btnx2.TabIndex = 22;
            this.btnx2.Text = "x2";
            this.btnx2.UseVisualStyleBackColor = true;
            this.btnx2.Click += new System.EventHandler(this.btnx2_Click);
            // 
            // btnasterisco
            // 
            this.btnasterisco.Location = new System.Drawing.Point(448, 264);
            this.btnasterisco.Name = "btnasterisco";
            this.btnasterisco.Size = new System.Drawing.Size(58, 37);
            this.btnasterisco.TabIndex = 23;
            this.btnasterisco.Text = "*";
            this.btnasterisco.UseVisualStyleBackColor = true;
            this.btnasterisco.Click += new System.EventHandler(this.btnasterisco_Click);
            // 
            // btnmenos
            // 
            this.btnmenos.Location = new System.Drawing.Point(448, 304);
            this.btnmenos.Name = "btnmenos";
            this.btnmenos.Size = new System.Drawing.Size(58, 37);
            this.btnmenos.TabIndex = 24;
            this.btnmenos.Text = "-";
            this.btnmenos.UseVisualStyleBackColor = true;
            this.btnmenos.Click += new System.EventHandler(this.btnmenos_Click);
            // 
            // btnigual
            // 
            this.btnigual.Location = new System.Drawing.Point(512, 304);
            this.btnigual.Name = "btnigual";
            this.btnigual.Size = new System.Drawing.Size(58, 81);
            this.btnigual.TabIndex = 25;
            this.btnigual.Text = "=";
            this.btnigual.UseVisualStyleBackColor = true;
            this.btnigual.Click += new System.EventHandler(this.btnigual_Click);
            // 
            // btndivisao
            // 
            this.btndivisao.Location = new System.Drawing.Point(512, 221);
            this.btndivisao.Name = "btndivisao";
            this.btndivisao.Size = new System.Drawing.Size(58, 37);
            this.btndivisao.TabIndex = 26;
            this.btndivisao.Text = "%";
            this.btndivisao.UseVisualStyleBackColor = true;
            this.btndivisao.Click += new System.EventHandler(this.btndivisao_Click);
            // 
            // btnmais
            // 
            this.btnmais.Location = new System.Drawing.Point(448, 347);
            this.btnmais.Name = "btnmais";
            this.btnmais.Size = new System.Drawing.Size(58, 37);
            this.btnmais.TabIndex = 27;
            this.btnmais.Text = "+";
            this.btnmais.UseVisualStyleBackColor = true;
            this.btnmais.Click += new System.EventHandler(this.btnmais_Click);
            // 
            // bntponto
            // 
            this.bntponto.Location = new System.Drawing.Point(384, 348);
            this.bntponto.Name = "bntponto";
            this.bntponto.Size = new System.Drawing.Size(58, 37);
            this.bntponto.TabIndex = 28;
            this.bntponto.Text = ".";
            this.bntponto.UseVisualStyleBackColor = true;
            this.bntponto.Click += new System.EventHandler(this.bntponto_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bntponto);
            this.Controls.Add(this.btnmais);
            this.Controls.Add(this.btndivisao);
            this.Controls.Add(this.btnigual);
            this.Controls.Add(this.btnmenos);
            this.Controls.Add(this.btnasterisco);
            this.Controls.Add(this.btnx2);
            this.Controls.Add(this.btnbarra);
            this.Controls.Add(this.btnmaismenos);
            this.Controls.Add(this.btnraizquadrada);
            this.Controls.Add(this.btnc);
            this.Controls.Add(this.btnce);
            this.Controls.Add(this.btnseta);
            this.Controls.Add(this.btnmmais);
            this.Controls.Add(this.btnmmenos);
            this.Controls.Add(this.btnms);
            this.Controls.Add(this.btnmr);
            this.Controls.Add(this.btnmc);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn0);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Calculadora";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnmc;
        private System.Windows.Forms.Button btnmr;
        private System.Windows.Forms.Button btnms;
        private System.Windows.Forms.Button btnmmenos;
        private System.Windows.Forms.Button btnmmais;
        private System.Windows.Forms.Button btnseta;
        private System.Windows.Forms.Button btnce;
        private System.Windows.Forms.Button btnc;
        private System.Windows.Forms.Button btnraizquadrada;
        private System.Windows.Forms.Button btnmaismenos;
        private System.Windows.Forms.Button btnbarra;
        private System.Windows.Forms.Button btnx2;
        private System.Windows.Forms.Button btnasterisco;
        private System.Windows.Forms.Button btnmenos;
        private System.Windows.Forms.Button btnigual;
        private System.Windows.Forms.Button btndivisao;
        private System.Windows.Forms.Button btnmais;
        private System.Windows.Forms.Button bntponto;
    }
}

