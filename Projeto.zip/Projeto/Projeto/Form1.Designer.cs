﻿namespace Projeto
{
    partial class FrmDados
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmDados));
            this.txtInteiro = new System.Windows.Forms.TextBox();
            this.txtDecimal = new System.Windows.Forms.TextBox();
            this.txtBoleano = new System.Windows.Forms.TextBox();
            this.txtTexto = new System.Windows.Forms.TextBox();
            this.lblInteiro = new System.Windows.Forms.Label();
            this.lbltexto = new System.Windows.Forms.Label();
            this.lblDecimal = new System.Windows.Forms.Label();
            this.lblBoleano = new System.Windows.Forms.Label();
            this.btnEnviar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtInteiro
            // 
            this.txtInteiro.Location = new System.Drawing.Point(17, 96);
            this.txtInteiro.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.txtInteiro.Name = "txtInteiro";
            this.txtInteiro.Size = new System.Drawing.Size(346, 47);
            this.txtInteiro.TabIndex = 0;
            this.txtInteiro.Tag = "txtInteiro";
            this.txtInteiro.TextChanged += new System.EventHandler(this.txtInteiro_TextChanged);
            // 
            // txtDecimal
            // 
            this.txtDecimal.Location = new System.Drawing.Point(17, 358);
            this.txtDecimal.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.txtDecimal.Name = "txtDecimal";
            this.txtDecimal.Size = new System.Drawing.Size(346, 47);
            this.txtDecimal.TabIndex = 2;
            this.txtDecimal.Tag = "txtDecimal";
            this.txtDecimal.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // txtBoleano
            // 
            this.txtBoleano.Location = new System.Drawing.Point(17, 504);
            this.txtBoleano.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.txtBoleano.Name = "txtBoleano";
            this.txtBoleano.Size = new System.Drawing.Size(346, 47);
            this.txtBoleano.TabIndex = 3;
            this.txtBoleano.Tag = "txtBoleano";
            this.txtBoleano.TextChanged += new System.EventHandler(this.txtBoleano_TextChanged);
            // 
            // txtTexto
            // 
            this.txtTexto.Location = new System.Drawing.Point(17, 225);
            this.txtTexto.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.txtTexto.Name = "txtTexto";
            this.txtTexto.Size = new System.Drawing.Size(346, 47);
            this.txtTexto.TabIndex = 4;
            this.txtTexto.Tag = "txtTexto";
            this.txtTexto.TextChanged += new System.EventHandler(this.txtTexto_TextChanged);
            // 
            // lblInteiro
            // 
            this.lblInteiro.AutoSize = true;
            this.lblInteiro.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblInteiro.Location = new System.Drawing.Point(17, 48);
            this.lblInteiro.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblInteiro.Name = "lblInteiro";
            this.lblInteiro.Size = new System.Drawing.Size(103, 39);
            this.lblInteiro.TabIndex = 5;
            this.lblInteiro.Tag = "";
            this.lblInteiro.Text = "Inteiro";
            this.lblInteiro.Click += new System.EventHandler(this.lblInteiro_Click);
            // 
            // lbltexto
            // 
            this.lbltexto.AutoSize = true;
            this.lbltexto.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbltexto.Location = new System.Drawing.Point(17, 177);
            this.lbltexto.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lbltexto.Name = "lbltexto";
            this.lbltexto.Size = new System.Drawing.Size(88, 39);
            this.lbltexto.TabIndex = 6;
            this.lbltexto.Tag = "lblTexto";
            this.lbltexto.Text = "Texto";
            this.lbltexto.Click += new System.EventHandler(this.lbltexto_Click);
            // 
            // lblDecimal
            // 
            this.lblDecimal.AutoSize = true;
            this.lblDecimal.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblDecimal.Location = new System.Drawing.Point(18, 310);
            this.lblDecimal.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblDecimal.Name = "lblDecimal";
            this.lblDecimal.Size = new System.Drawing.Size(122, 39);
            this.lblDecimal.TabIndex = 7;
            this.lblDecimal.Tag = "";
            this.lblDecimal.Text = "Decimal";
            this.lblDecimal.Click += new System.EventHandler(this.lblDecimal_Click);
            // 
            // lblBoleano
            // 
            this.lblBoleano.AutoSize = true;
            this.lblBoleano.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblBoleano.Location = new System.Drawing.Point(18, 456);
            this.lblBoleano.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblBoleano.Name = "lblBoleano";
            this.lblBoleano.Size = new System.Drawing.Size(123, 39);
            this.lblBoleano.TabIndex = 8;
            this.lblBoleano.Tag = "";
            this.lblBoleano.Text = "Boleano";
            this.lblBoleano.Click += new System.EventHandler(this.lblBoleano_Click);
            // 
            // btnEnviar
            // 
            this.btnEnviar.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnEnviar.Font = new System.Drawing.Font("Cambria", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnviar.Location = new System.Drawing.Point(590, 152);
            this.btnEnviar.Name = "btnEnviar";
            this.btnEnviar.Size = new System.Drawing.Size(246, 82);
            this.btnEnviar.TabIndex = 9;
            this.btnEnviar.Text = "Enviar";
            this.btnEnviar.UseVisualStyleBackColor = false;
            this.btnEnviar.Click += new System.EventHandler(this.btnEnviar_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnLimpar.Font = new System.Drawing.Font("Cambria", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(590, 263);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(246, 82);
            this.btnLimpar.TabIndex = 10;
            this.btnLimpar.Tag = "btnLimpar";
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // FrmDados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 39F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.BackgroundImage = global::Projeto.Properties.Resources.Destacada_Qual_tipo_de_Banco_de_Dados_utilizar;
            this.ClientSize = new System.Drawing.Size(994, 881);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnEnviar);
            this.Controls.Add(this.lblBoleano);
            this.Controls.Add(this.lblDecimal);
            this.Controls.Add(this.lbltexto);
            this.Controls.Add(this.lblInteiro);
            this.Controls.Add(this.txtTexto);
            this.Controls.Add(this.txtBoleano);
            this.Controls.Add(this.txtDecimal);
            this.Controls.Add(this.txtInteiro);
            this.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.Name = "FrmDados";
            this.Text = "Capiturando dados na tela ";
            this.Load += new System.EventHandler(this.FrmDados_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtInteiro;
        private System.Windows.Forms.TextBox txtDecimal;
        private System.Windows.Forms.TextBox txtBoleano;
        private System.Windows.Forms.TextBox txtTexto;
        private System.Windows.Forms.Label lblInteiro;
        private System.Windows.Forms.Label lbltexto;
        private System.Windows.Forms.Label lblDecimal;
        private System.Windows.Forms.Label lblBoleano;
        private System.Windows.Forms.Button btnEnviar;
        private System.Windows.Forms.Button btnLimpar;
    }
}

