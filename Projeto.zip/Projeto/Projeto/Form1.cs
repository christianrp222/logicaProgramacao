﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto
{
    public partial class FrmDados : Form
    {
        public FrmDados()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Escrenvendo os Texto");
        }

        private void Label4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Label");
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Escrenvendo os Texto");
        }

        private void Label1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Label");
        }

        private void lblInteiro_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Label");
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Enviou");
        }

        private void lbltexto_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Label");
        }

        private void lblDecimal_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Label");
        }

        private void lblBoleano_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Label");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Limpou");
        }

        private void txtInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Mensagem");
        }

        private void txtTexto_TextChanged(object sender, EventArgs e)
        {

            MessageBox.Show("Mensagem");
        }

        private void txtBoleano_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Mensagem");
        }

        private void FrmDados_Load(object sender, EventArgs e)
        {

        }
    }
}
